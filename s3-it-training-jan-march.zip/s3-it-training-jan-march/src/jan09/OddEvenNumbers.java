package jan09;
import java.util.Scanner;
public class OddEvenNumbers {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter a number:\n");
        int number = input.nextInt();
        if(number % 2 == 0){
            System.out.println("It is an even Number\n");
        }else{
            System.out.println("It is a odd number\n");
        }
    }
}
